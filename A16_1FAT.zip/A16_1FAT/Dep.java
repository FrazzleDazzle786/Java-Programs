/*
child class of Faculty
*/
public class Dep extends Faculty
{
   //protected String specialty;
   private String specialty;

   public Dep (String empName, int empNumber, String special)
   {
      super (empName, empNumber);
      specialty = special;
   }

   public void setSpecialty (String special)
   {
      specialty = special;
   }

   public String getSpecialty()
   {
      return specialty;
   }

   public void DeptInfo()
   {
      System.out.println ("Department: " + specialty);
   }
}
