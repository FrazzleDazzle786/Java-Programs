/*********************************
Programmers: Fraz Tariq
Date: September 18th, 2017
Output: Array Exercise
**********************************/
import java.util.Scanner; // import Java package
public class A16_1FAT
{
   public static void main (String[] args)
   {
	  Scanner keyboard = new Scanner(System.in);
	  String name;
	  String Department;
	  int ID;
	  System.out.print("Enter Faculty Name: ");
	  name = keyboard.nextLine();
	  System.out.print("Enter Faculty ID: ");
	  ID = keyboard.nextInt();
	  keyboard.nextLine();
	  System.out.print("Enter Faculty Department: ");
	  Department = keyboard.nextLine();

	  System.out.println(" ");


      Faculty vito = new Faculty (name, ID);
      Dep michael = new Dep (name, ID, Department);

      // invoke the specific methods of the objects
      vito.facInfo();
      michael.DeptInfo();

   }
}
