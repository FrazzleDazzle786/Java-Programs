/*
act 16 solution
super class
*/
public class Faculty
{
   //protected String name;
   //protected int number;
   private String name;
   private int number;

   public Faculty (String empName, int empNumber)
   {
      name = empName;
      number = empNumber;
   }

   public void setName (String empName)
   {
      name = empName;
   }

   public void setNumber (int empNumber)
   {
      number = empNumber;
   }

   public String getName()
   {
      return name;
   }

   public int getNumber()
   {
      return number;
   }

   public void facInfo()
   {
      System.out.println ("Faculty Name: " + name);
      System.out.println ("Faculty ID: " + number);
   }
}
