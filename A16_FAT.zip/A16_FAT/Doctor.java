/*********************************
Programmers: Fraz Tariq
Date: November 17th, 2017
Output: Array Exercise
**********************************/
import java.util.Scanner; // import Java package
public class Doctor extends HospitalEmployee
{
	//Scanner keyboard = new Scanner(System.in);
	String Specialty;


	  //constructor
	  public Doctor(String EmployeeName, int EmployeeNumber, String EmployeeSpecialty)
	  {
		  super(EmployeeName, EmployeeNumber);
		  Specialty = "Heart Doctor";

	  }


	  public void setSpecialty()
	  {
		  System.out.println("Enter the Employees Specialty");
		  Specialty = keyboard.nextLine();
	  }

	  public String getSpecialty()
	  {
		  return Specialty;
	  }

	  public void Diagnose()
	  {
		  System.out.println(super.name + " is a(n) " + getSpecialty());
	  }










}