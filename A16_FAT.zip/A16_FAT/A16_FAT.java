/*********************************
Programmers: Fraz Tariq
Date: November 20th, 2017
Output: Superclass Exercise
**********************************/
import java.util.Scanner; // import Java package
public class A16_FAT
{
	public static void main(String[] args)
	{
		String name = " ";
		String specialty = " ";
		int number = 0;
		HospitalEmployee Fraz = new HospitalEmployee(name, number);
		Doctor Fraz2 = new Doctor(name, number, specialty);

		//Fraz.setName();
		//Fraz.setNumber();
		//Fraz2.setSpecialty();
		Fraz.work();
		Fraz2.Diagnose();
	}
















}