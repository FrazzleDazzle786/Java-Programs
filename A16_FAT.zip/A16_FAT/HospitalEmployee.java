/*********************************
Programmers: Fraz Tariq
Date: November 17th, 2017
Output: Array Exercise
**********************************/
import java.util.Scanner; // import Java package
public class HospitalEmployee
{
	Scanner keyboard = new Scanner(System.in);
	int number;
	String name;

	  //constructor
	  public HospitalEmployee(String EmployeeName, int EmployeeNumber)
	  {
		  name = "Vito";
		  number = EmployeeNumber;
	  }


	  public void setName()
	  {
		  System.out.print("Enter the Employees Name: ");
		  name = keyboard.nextLine();
	  }

	  public String getName()
	  {
		  return name;
	  }

	  public void setNumber()
	  {
	  		  System.out.print("Enter the Employees Number: ");
	  		  number = keyboard.nextInt();
	  }

	  public int getNumber()
	  {
		  return number;
	  }

	  public void work()
	  {
		  System.out.println(getName() + " works for the hospital");
	  }
















}